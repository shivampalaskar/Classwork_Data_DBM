//============================================================================
// Name        : Day4_1.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main()
{
	int n1=10,n2=0;
	cout<<n1/n2;
	return 0;
}


/*


double division(int a, int b)
{
	if( b == 0 )
	{
			throw "Division by zero condition!";
	}
	return (a/b);
}


int main ()
{
	int x,y;
	cout<<"Enter value 1 :";
	cin>>x;
	cout<<"\n Enter value 2 :";
	cin>>y;
	double z = 0;
	try
	{
		z = division(x, y);
		cout << z << endl;
	}
	catch (const char* msg)
	{
		cerr << msg << endl;
	}

return 0;
}
*/
