//============================================================================
// Name        : Day3_1.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
#include "test.h"

int main()
{
	Employee emp;
	emp.display();
	Employee emp1(2,60000);
	emp1.display();
	return 0;
}
