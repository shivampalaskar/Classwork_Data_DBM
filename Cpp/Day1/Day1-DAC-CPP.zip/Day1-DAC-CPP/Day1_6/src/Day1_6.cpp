//============================================================================
// Name        : Day1_6.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include<string>
using namespace std;

int main()
{
	int n1,n2;
	string name;//string is a class
	cout<<"\n Enter N1 Value : ";
	cin>>n1;
	cout<<"\n Enter n2 value ";
	cin>>n2;
	cout<<"\n Addition "<<n1+n2;
	cout<<"\n Enter string value";
	cin>>name;

	cout<<"\n Name "<<name;

	return 0;
}






