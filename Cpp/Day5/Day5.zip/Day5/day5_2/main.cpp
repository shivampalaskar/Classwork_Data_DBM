/*
 * main.cpp
 *
 *  Created on: 06-Mar-2020
 *      Author: nilesh
 */

#include <iostream>
using namespace std;
#include "matrix.h"

int main() {
	matrix m1(2,3);
	m1.accept();
	m1.display();
	return 0;
}



