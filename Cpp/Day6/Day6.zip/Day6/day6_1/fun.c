/*
 * fun.c
 *
 *  Created on: 07-Mar-2020
 *      Author: nilesh
 */

#include <stdio.h>

void fun(int a) {
	printf("fun() called: %d\n", a);
}




