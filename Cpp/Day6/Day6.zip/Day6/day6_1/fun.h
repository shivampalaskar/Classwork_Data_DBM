/*
 * fun.h
 *
 *  Created on: 07-Mar-2020
 *      Author: nilesh
 */

#ifndef FUN_H_
#define FUN_H_

extern "C" void fun(int a);

#endif /* FUN_H_ */
