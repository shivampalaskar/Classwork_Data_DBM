/*
 * main.cpp
 *
 *  Created on: 07-Mar-2020
 *      Author: nilesh
 */

#include <iostream>
using namespace std;
#include "manager.h"

int main() {
	/*
	manager m1;
	cout << "sizeof(m) = " << sizeof(m1) << endl;
	*/

	/*
	manager m2(1, 10000.0, 200.0);
	m2.display();
	*/


	return 0;
}


