/*
 * test.h
 *
 *  Created on: 04-Mar-2020
 *      Author: sunbeam
 */

#ifndef TEST_H_
#define TEST_H_
//declaration of class
class Employee
{
private:
	int id;
	int salary;
public:
	//declaration of member functions
	Employee();
	Employee(int id,int salary);
	void display();
};





#endif /* TEST_H_ */
